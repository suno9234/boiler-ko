module.exports ={
    mongoURI:'mongodb+srv://admin:as39as@cluster0.7aa25.mongodb.net/test?retryWrites=true&w=majority'
}